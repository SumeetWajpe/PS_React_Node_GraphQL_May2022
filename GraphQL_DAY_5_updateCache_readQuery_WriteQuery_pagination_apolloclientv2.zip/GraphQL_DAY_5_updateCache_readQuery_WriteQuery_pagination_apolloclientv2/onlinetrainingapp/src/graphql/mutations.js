import { gql } from "@apollo/client";

export const ADD_TRAINER = gql`
  mutation AddTrainer($id: ID!, $name: String!, $age: Int, $isMCT: Boolean) {
    addTrainer(id: $id, name: $name, age: $age, isMCT: $isMCT) {
      name
    }
  }
`;

export const DELETE_COURSE = gql`
  mutation DeleteCourse($id: ID!) {
    deleteCourse(id: $id) {
      title
    }
  }
`;

export const ADD_NEW_COURSE = gql`
  mutation AddCourse(
    $id: ID!
    $title: String!
    $price: Int
    $rating: Int
    $likes: Int
    $imageUrl: String
    $trainerId: ID
  ) {
    addCourse(
      id: $id
      title: $title
      price: $price
      rating: $rating
      likes: $likes
      imageUrl: $imageUrl
      trainerId: $trainerId
    ) {
      id
      title
      price
      rating
      likes
      imageUrl
      trainer {
        name
      }
    }
  }
`;
