import { useMutation } from "@apollo/client";
import React, { useState } from "react";
import { DELETE_COURSE } from "../graphql/mutations";
import { GET_ALL_COURSES } from "../graphql/queries";
function Course(props) {
  const [deleteCourse, { data, loading, error }] = useMutation(DELETE_COURSE, {
    variables: { id: props.coursedetails.id },
    refetchQueries: [{ query: GET_ALL_COURSES }],
    // update() -> update the cache !
  });

  var ratings = [];
  for (let index = 0; index < props.coursedetails.rating; index++) {
    ratings.push(
      <span style={{ color: "orange" }} key={index}>
        <i className="fa-solid fa-star"></i>
      </span>
    );
  }

  return (
    <div className="col-md-3 my-1">
      <div className="card p-1">
        <img
          height="170px"
          src={props.coursedetails.imageUrl}
          alt={props.coursedetails.name}
          className="card-img-top"
        />
        <div className="card-body">
          <p>{ratings}</p>

          <h4 className="card-title">{props.coursedetails.title}</h4>
          <h5 className="card-text">₹. {props.coursedetails.price}</h5>
          <h5 className="card-text">{props.coursedetails.trainer.name}</h5>

          <button className="btn btn-primary mx-1">
            {props.coursedetails.likes}
            <i className="fa-solid fa-thumbs-up"></i>
          </button>

          <button
            className="btn btn-danger mx-1"
            onClick={() => deleteCourse(props.coursedetails.id)}
          >
            <i className="fa-solid fa-trash-can"></i>
          </button>
        </div>
      </div>
    </div>
  );
}

export default Course;
