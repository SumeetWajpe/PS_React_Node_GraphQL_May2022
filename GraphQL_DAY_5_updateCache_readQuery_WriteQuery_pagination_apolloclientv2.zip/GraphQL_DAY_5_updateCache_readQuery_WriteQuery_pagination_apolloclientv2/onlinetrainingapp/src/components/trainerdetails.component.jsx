import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { client } from "../index";
import { GET_ALL_TRAINERS, GET_TRAINER_DETAILS } from "../graphql/queries";

export default function TrainerDetails() {
  const [theTrainer, setTheTrainer] = useState({
    id: 0,
    name: "",
    age: 0,
    isMCT: false,
    courses: [],
    avatarUrl: "",
    description: "",
  });
  const { id } = useParams();

  // const { loading, data, error } = useQuery(GET_TRAINER_DETAILS, {
  //   variables: { trainerId: id },
  //   // fetchPolicy: "network-only", // fetches the data from graphql-server eachtime
  // });

  useEffect(() => {
    // when fetching from cache !
    const { trainers } = client.readQuery({
      query: GET_ALL_TRAINERS,
    });
    let theTrainer = trainers.find((t) => t.id == id);
    setTheTrainer(theTrainer);

    // when fetching from server !
    //setTheTrainer(trainer);
    // if (!loading) {
    //   setTheTrainer(data.trainer);
    // }
  });
  return (
    <div className="alert alert-secondary">
      <h2>Trainer details for Id : {id}</h2>

      <div className="card mb-3">
        <div class="row g-0">
          <div class="col-md-4">
            <img
              src={theTrainer?.avatarUrl}
              class="img-fluid rounded-start"
              alt={theTrainer.name}
            />
          </div>
          <div class="col-md-8">
            <div class="card-body">
              <h5 class="card-title">{theTrainer?.name}</h5>
              <p class="card-text">Age : {theTrainer?.age}</p>
              <p class="card-text">About : {theTrainer?.description}</p>
              <strong>Courses Delivered : </strong>
              <ul className="list-group">
                {theTrainer.courses.map((course, index) => (
                  <li className="list-group-item" key={index}>
                    {course.title}
                  </li>
                ))}
              </ul>
              <p class="card-text">
                <small class="text-muted">
                  {theTrainer.isMCT ? "Microsoft Certified Trainer" : ""}
                </small>
              </p>
            </div>
          </div>
        </div>
      </div>
      {/* <section>
        <div>
          <h3>Name : {theTrainer?.name}</h3>
          <h3>Age : {theTrainer?.age}</h3>
          <h3>Is an MCT ? {theTrainer?.isMCT ? " YES " : " NO "}</h3>
          <strong>Courses Delivered : </strong>
          <ul>
            {theTrainer.courses.map((course, index) => (
              <li key={index}>{course.title}</li>
            ))}
          </ul>
        </div>
      </section> */}
    </div>
  );
}

// import { useQuery } from "@apollo/client";
// import React, { useEffect, useState } from "react";
// import { useParams } from "react-router-dom";
// import { GET_TRAINER_DETAILS } from "../graphql/queries";

// export default function TrainerDetails() {
//   const [theTrainer, setTheTrainer] = useState({
//     id: 0,
//     name: "",
//     age: 0,
//     isMCT: false,
//     courses: [],
//   });
//   const { id } = useParams();

//   const { loading, data, error } = useQuery(GET_TRAINER_DETAILS, {
//     variables: { trainerId: id },
//     // fetchPolicy: "network-only", // fetches the data from graphql-server eachtime
//   });

//   useEffect(() => {
//     if (!loading) {
//       setTheTrainer(data.trainer);
//     }
//   });
//   return (
//     <div className="alert alert-secondary">
//       <h2>Trainer details for {id}</h2>
//       <section>
//         {loading == false ? (
//           <div>
//             <h3>Name : {theTrainer.name}</h3>
//             <h3>Age : {theTrainer.age}</h3>
//             <h3>Is an MCT ? {theTrainer.isMCT ? " YES " : " NO "}</h3>
//             <strong>Courses Delivered : </strong>
//             <ul>
//               {theTrainer.courses.map((course) => (
//                 <li key={course.id}>{course.title}</li>
//               ))}
//             </ul>
//           </div>
//         ) : (
//           ""
//         )}
//       </section>
//     </div>
//   );
// }
