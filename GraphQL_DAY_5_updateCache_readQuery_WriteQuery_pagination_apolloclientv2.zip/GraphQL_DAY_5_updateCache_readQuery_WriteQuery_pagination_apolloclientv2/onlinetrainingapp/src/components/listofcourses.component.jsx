import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { GET_ALL_COURSES } from "../graphql/queries";
import Course from "./course.component";

function ListOfCourses() {
  const PAGE_SIZE = 4;
  const [page, setPage] = useState(0);
  const { error, loading, data } = useQuery(GET_ALL_COURSES, {
    variables: {
      limit: PAGE_SIZE,
      offset: PAGE_SIZE * page,
    },
  });
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    if (!loading) {
      console.log(data.courses);
      setCourses(data.courses);
    }
  }, [data]);

  let coursesToBeCreated = courses.map((course) => (
    <Course coursedetails={course} key={course.id} />
  ));
  return (
    <>
      <header>
        <h1> List Of Courses</h1>
      </header>
      <main>
        <div className="row justify-content-between">
          <div className="col-1">
            <button
              className="btn btn-primary"
              disabled={!page}
              onClick={() => setPage((prev) => prev - 1)}
            >
              <i className="fa-solid fa-angles-left"></i> Prev
            </button>
          </div>
          <div className="col-1">
            <span>Page - {page + 1} </span>
          </div>
          <div className="col-1">
            <button
              className="btn btn-primary"
              onClick={() => setPage((prev) => prev + 1)}
            >
              Next <i className="fa-solid fa-angles-right"></i>
            </button>
          </div>
        </div>
        <div className="row">
          {loading ? <h4>Loading...</h4> : coursesToBeCreated}
        </div>
      </main>
    </>
  );
}

export default ListOfCourses;
