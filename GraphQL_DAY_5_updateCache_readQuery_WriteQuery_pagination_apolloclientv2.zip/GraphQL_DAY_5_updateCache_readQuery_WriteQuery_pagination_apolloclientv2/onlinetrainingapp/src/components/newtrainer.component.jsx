import React, { useEffect, useState } from "react";
import { ADD_TRAINER } from "../graphql/mutations";
import { useMutation } from "@apollo/client";

export default function NewTrainer() {
  const [newTrainer, setNewTrainer] = useState({
    id: 0,
    name: "",
    age: 0,
    isMCT: false,
  });

  const [addTrainer, { data, error, loading }] = useMutation(ADD_TRAINER, {
    variables: {
      id: newTrainer.id,
      name: newTrainer.name,
      age: parseInt(newTrainer.age),
      isMCT: newTrainer.isMCT == "yes" ? true : false, // avatarUrl , description
    },
  });
  useEffect(() => {
    if (!loading) {
      console.log(data);
    }
  }, [data]);
  return (
    <div>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          console.log(newTrainer);
          // add new trainer
          addTrainer();
        }}
      >
        <label>
          Id :{" "}
          <input
            type="text"
            onChange={(e) =>
              setNewTrainer({ ...newTrainer, id: e.target.value })
            }
          />
        </label>
        <br />
        <label>
          Name :{" "}
          <input
            type="text"
            onChange={(e) =>
              setNewTrainer({ ...newTrainer, name: e.target.value })
            }
          />
        </label>
        <br />
        <label>
          Age :{" "}
          <input
            type="number"
            onChange={(e) =>
              setNewTrainer({ ...newTrainer, age: e.target.value })
            }
          />
        </label>
        <br />
        <label>
          isMCT :{" "}
          <input
            type="text"
            onChange={(e) =>
              setNewTrainer({ ...newTrainer, isMCT: e.target.value })
            }
          />
        </label>
        <br />
        <button>Add Trainer</button>
      </form>
    </div>
  );
}
