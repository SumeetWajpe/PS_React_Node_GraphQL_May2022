import React from 'react';

interface IBasicProps{
    msg:string
}

// React.Component<PropTypes>
export default class BasicComponent extends React.Component<IBasicProps>{
    static defaultProps ={
        msg:"Hello !!"
    }    
    render(){
        return <h1>{this.props.msg}</h1>
        }
}