import { gql } from "@apollo/client";

export const ADD_TRAINER = gql`
  mutation AddTrainer($id: ID!, $name: String!, $age: Int, $isMCT: Boolean) {
    addTrainer(id: $id, name: $name, age: $age, isMCT: $isMCT) {
      name
    }
  }
`;
