import { gql } from "@apollo/client";

export const GET_ALL_TRAINERS = gql`
  query {
    trainers {
      id
      name
    }
  }
`;

export const GET_ALL_COURSES = gql`
  query GetAllCourses {
    courses {
      id
      title
      price
      rating
      likes
      imageUrl
    }
  }
`;

export const GET_TRAINER_BY_ID = gql`
  query GetTrainerById($trainerId: ID!) {
    trainer(id: $trainerId) {
      name
    }
  }
`;
