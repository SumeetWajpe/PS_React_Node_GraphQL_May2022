import GetTrainerById from "./getTrainerById.component";
import ListOfCourses from "./listofcourses.component";
import NewTrainer from "./newtrainer.component";
import ListOfTrainers from "./trainers.component";

function App() {
  return (
    <div className="App">
      {/* <ListOfTrainers /> */}
      {/* <GetTrainerById /> */}
      {/* <NewTrainer /> */}
      <ListOfCourses />
    </div>
  );
}

export default App;
