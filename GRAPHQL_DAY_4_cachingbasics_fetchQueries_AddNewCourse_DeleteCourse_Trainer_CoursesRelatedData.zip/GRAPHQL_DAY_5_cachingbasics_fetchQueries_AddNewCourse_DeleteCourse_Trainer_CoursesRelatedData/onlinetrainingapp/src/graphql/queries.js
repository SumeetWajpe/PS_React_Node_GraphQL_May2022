import { gql } from "@apollo/client";

export const GET_ALL_TRAINERS = gql`
  query {
    trainers {
      id
      name
      age
      isMCT
      courses {
        title
      }
    }
  }
`;

export const GET_ALL_COURSES = gql`
  query GetAllCourses {
    courses {
      id
      title
      price
      rating
      likes
      imageUrl
      trainer {
        name
      }
    }
  }
`;

export const GET_TRAINER_BY_ID = gql`
  query GetTrainerById($trainerId: ID!) {
    trainer(id: $trainerId) {
      name
    }
  }
`;

export const GET_TRAINER_DETAILS = gql`
  query GetTrainerDetails($trainerId: ID!) {
    trainer(id: $trainerId) {
      id
      name
      age
      isMCT
      courses {
        title
      }
    }
  }
`;
