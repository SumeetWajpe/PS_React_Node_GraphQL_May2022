import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { GET_ALL_COURSES } from "../graphql/queries";
import Course from "./course.component";

function ListOfCourses() {
  const { error, loading, data } = useQuery(GET_ALL_COURSES);
  const [courses, setCourses] = useState([]);

  useEffect(() => {
    if (!loading) {
      console.log(data.courses);
      setCourses(data.courses);
    }
  }, [data]);

  let coursesToBeCreated = courses.map((course) => (
    <Course coursedetails={course} key={course.id} />
  ));
  return (
    <>
      <header>
        <h1> List Of Courses</h1>
      </header>
      <main>
        <div className="row">
          {loading ? <h4>Loading...</h4> : coursesToBeCreated}
        </div>
      </main>
    </>
  );
}

export default ListOfCourses;
