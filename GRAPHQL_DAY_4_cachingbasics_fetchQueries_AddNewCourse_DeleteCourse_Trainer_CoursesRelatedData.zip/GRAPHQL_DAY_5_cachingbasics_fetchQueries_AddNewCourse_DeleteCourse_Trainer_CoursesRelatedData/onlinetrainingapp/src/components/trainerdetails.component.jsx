import { useQuery } from "@apollo/client";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { client } from "../index";
import { GET_TRAINER_DETAILS } from "../graphql/queries";

export default function TrainerDetails() {
  const [theTrainer, setTheTrainer] = useState({
    id: 0,
    name: "",
    age: 0,
    isMCT: false,
    courses: [],
  });
  const { id } = useParams();

  client.readQuery({
    query: GET_TRAINER_DETAILS,
    variables: { trainerId: id },
  });

    const { loading, data, error } = useQuery(GET_TRAINER_DETAILS, {
      variables: { trainerId: id },
      // fetchPolicy: "network-only", // fetches the data from graphql-server eachtime
    });

  useEffect(() => {
    if (!loading) {
      setTheTrainer(data.trainer);
    }
  });
  return (
    <div className="alert alert-secondary">
      <h2>Trainer details for {id}</h2>
      <section>
        {loading == false ? (
          <div>
            <h3>Name : {theTrainer.name}</h3>
            <h3>Age : {theTrainer.age}</h3>
            <h3>Is an MCT ? {theTrainer.isMCT ? " YES " : " NO "}</h3>
            <strong>Courses Delivered : </strong>
            <ul>
              {theTrainer.courses.map((course) => (
                <li key={course.id}>{course.title}</li>
              ))}
            </ul>
          </div>
        ) : (
          ""
        )}
      </section>
    </div>
  );
}

// import { useQuery } from "@apollo/client";
// import React, { useEffect, useState } from "react";
// import { useParams } from "react-router-dom";
// import { GET_TRAINER_DETAILS } from "../graphql/queries";

// export default function TrainerDetails() {
//   const [theTrainer, setTheTrainer] = useState({
//     id: 0,
//     name: "",
//     age: 0,
//     isMCT: false,
//     courses: [],
//   });
//   const { id } = useParams();

//   const { loading, data, error } = useQuery(GET_TRAINER_DETAILS, {
//     variables: { trainerId: id },
//     // fetchPolicy: "network-only", // fetches the data from graphql-server eachtime
//   });

//   useEffect(() => {
//     if (!loading) {
//       setTheTrainer(data.trainer);
//     }
//   });
//   return (
//     <div className="alert alert-secondary">
//       <h2>Trainer details for {id}</h2>
//       <section>
//         {loading == false ? (
//           <div>
//             <h3>Name : {theTrainer.name}</h3>
//             <h3>Age : {theTrainer.age}</h3>
//             <h3>Is an MCT ? {theTrainer.isMCT ? " YES " : " NO "}</h3>
//             <strong>Courses Delivered : </strong>
//             <ul>
//               {theTrainer.courses.map((course) => (
//                 <li key={course.id}>{course.title}</li>
//               ))}
//             </ul>
//           </div>
//         ) : (
//           ""
//         )}
//       </section>
//     </div>
//   );
// }
