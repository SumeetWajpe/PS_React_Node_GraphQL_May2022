import Addition, { Product } from "./module.js";

console.log("The addition is : " + Addition(20, 30));
console.log(`The addition is :  ${Product(20, 30)}`);
