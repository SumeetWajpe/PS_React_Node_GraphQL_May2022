import logo from "./logo.svg";
import "./App.css";
import React from "react";
import { BasicComponent } from "./basic.component";
import Message from "./message.component";

class App extends React.Component {
  messages = [
    {
      msgText: "Hi",
      imageUrl:
        "https://i.pinimg.com/originals/d9/4a/49/d94a495eca526d82ebbe0640aea413a9.jpg",
    },
    {
      msgText: "Hola",
      imageUrl:
        "https://image.shutterstock.com/image-vector/hola-spanish-greeting-handwritten-white-260nw-1080284534.jpg",
    },
    {
      msgText: "Hey",
      imageUrl:
        "https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Hey_2018_logo.svg/1200px-Hey_2018_logo.svg.png",
    },
  ];
  render() {
    var msgsToBeCreated = this.messages.map((m) => (
      <div>
        <Message msg={m} />
        <hr />
      </div>
    ));
    return <div className="App">{msgsToBeCreated}</div>;
  }
}

export default App;
