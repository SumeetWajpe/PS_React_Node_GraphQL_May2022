import React, { Component } from "react";

export default class Message extends Component {
  render() {
    return (
      <div>
        <h2>{this.props.msg.msgText}</h2>
        <img
          src={this.props.msg.imageUrl}
          alt={this.props.msg}
          style={{ height: "150px", width: "150px" }}
        />
      </div>
    );
  }
}
