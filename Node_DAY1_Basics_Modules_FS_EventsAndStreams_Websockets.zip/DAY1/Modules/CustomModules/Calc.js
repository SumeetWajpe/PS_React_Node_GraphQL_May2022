var MathModule = require("./Math");
console.log(MathModule.Add(20, 30));
console.log(MathModule.Multiply(20, 30));
