var axios = require("axios").default;

let thePromise = axios.get("https://jsonplaceholder.typicode.com/posts");
thePromise
  .then((response) => console.log(response.data))
  .catch((err) => console.log(err));
