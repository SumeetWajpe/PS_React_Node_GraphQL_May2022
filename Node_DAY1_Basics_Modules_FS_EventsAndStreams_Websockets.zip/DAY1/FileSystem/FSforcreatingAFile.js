var fs = require("fs");

fs.mkdir("temp", function (err) {
  if (err) {
    console.log(err);
  } else {
    fs.access("temp", fs.constants.F_OK, (err) => {
      process.chdir("temp");
      fs.writeFile(
        "Test.txt",
        "This is a message to be written in Test.txt",
        (err) => {
          if (err) {
            console.log(err);
          } else {
            fs.readFile("Test.txt", (err, dataFromFile) => {
              console.log(dataFromFile.toString());
            });
          }
        }
      );
    });
  }
});
