var fs = require("fs");

// Non-blocking
fs.readFile("Input.txt", (err, dataFromFile) => {
  if (err) console.log(err);
  else console.log(dataFromFile);
});

// Blocking Code
// var dataFromFile = fs.readFileSync("Input.txt");
// console.log("Read file (Sync) : " + dataFromFile.toString());

console.log("Program Ended !");
