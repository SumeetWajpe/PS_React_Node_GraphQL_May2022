const http = require("http");
var fs = require("fs");
var socket = require("socket.io");
const hostname = "127.0.0.1";
const port = 3000;

const server = http.createServer((req, res) => {
  fs.readFile("ClientPeer.html", (err, data) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end(data);
  });
});

var io = socket(server); // socket reg on server
io.sockets.on("connection", function (skt) {
  setInterval(() => {
    var dataToBeSent = new Date();
    skt.emit("custom_msg_from_server_peer", dataToBeSent);
  },2000);

  skt.on("custom_msg_from_client_peer", (dataFromClientPeer) => {
    console.log("Data from Client Peer : " + dataFromClientPeer);
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
