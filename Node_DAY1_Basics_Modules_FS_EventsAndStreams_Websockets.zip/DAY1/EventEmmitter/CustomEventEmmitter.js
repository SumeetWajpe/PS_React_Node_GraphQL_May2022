let EventEmmitter = require("events").EventEmitter;
let evt = new EventEmmitter();

//publisher
function GetCount(maxIteration) {
  // logic
  // emit start event -> when iteration starts
  // emit count event -> pass current iteration count
  // emit finish event -> done !

  process.nextTick(function () {
    console.log("Emmitting started..");
    evt.emit("start");
    let cnt = 0;
    let timerId = setInterval(() => {
      evt.emit("count", ++cnt);

      if (cnt == 8) {
        evt.emit("error", cnt);
        clearInterval(timerId);
      }

      if (cnt == maxIteration) {
        evt.emit("finish", cnt);
        clearInterval(timerId);
      }
    }, 500);
  });

  return evt;
}

//subscriber

let e = GetCount(5);
e.on("start", function () {
  console.log("Iteration started..");
});

e.on("count", (currCount) => {
  console.log("Current Count : " + currCount);
});

e.on("finish", (finalCount) => {
  console.log("Finished with Final Count : " + finalCount);
});

e.on("error", (errCount) => {
  console.log("Ended with error with count : " + errCount);
});

console.log("Program Ended..");
