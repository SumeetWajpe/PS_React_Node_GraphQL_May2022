var fs = require("fs");




let readableStream = fs.createReadStream("Input.txt");
let writeableStream = fs.createWriteStream("Output.txt");

let allData = "";

// readableStream.on("data", function (chunk) {
//   allData += chunk;
//   console.log(">>>>>>>>>>>>>>>>>>>>> CHUNK >>>>>>>>>>>>>>>>>>>" + chunk);
// });

// readableStream.on("error", function (err) {
//   console.log(err);
// });

// readableStream.on("end", function () {
//   writeableStream.write(allData);
//   writeableStream.end();
// });

readableStream.pipe(writeableStream);
