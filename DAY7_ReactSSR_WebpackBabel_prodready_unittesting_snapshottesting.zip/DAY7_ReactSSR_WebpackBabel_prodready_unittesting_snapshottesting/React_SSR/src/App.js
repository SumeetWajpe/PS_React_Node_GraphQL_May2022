import logo from "./logo.svg";
import "./App.css";

import React from "react";

function App() {
  return <h1>Server side rendered app !</h1>;
}

export default App;
