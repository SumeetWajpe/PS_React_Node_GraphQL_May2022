export class Point {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  printPoint() {
    console.log(`The point is : [X:${this.x} , Y:${this.y}]`);
  }
}

export var Add = (x, y) => x + y;
