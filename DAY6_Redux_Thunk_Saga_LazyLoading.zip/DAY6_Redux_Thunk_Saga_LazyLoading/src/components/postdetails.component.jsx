import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useParams } from "react-router-dom";

export default function PostDetails() {
  let { id } = useParams();
  const [thePost, setThePost] = useState({
    id: "",
    title: "",
    body: "",
    userId: "",
  });
  const { posts } = useSelector((store) => store);

  useEffect(() => {
    var post = posts.find((p) => p.id == id);
    setThePost(post);
    // if posts is unavailable - dispatch an action for getting a particular post | ajax
  });
  return (
    <div className="alert alert-secondary">
      <h2>Post Details for {id}</h2>
      <h3>UserId : {thePost.userId}</h3>
      <h3>Title : {thePost.title}</h3>
      <h3>Body : {thePost.body}</h3>
    </div>
  );
}
