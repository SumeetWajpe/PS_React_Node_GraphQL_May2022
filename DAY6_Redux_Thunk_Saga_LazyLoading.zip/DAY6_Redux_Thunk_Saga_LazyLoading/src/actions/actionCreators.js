import axios from "axios";

const INCREMENT_LIKES = "INCREMENT_LIKES"; // best practice !

export function IncrementLikes(theCourseId) {
  return { type: INCREMENT_LIKES, theCourseId };
}

export function DeleteCourse(theCourseId) {
  return { type: "DELETE_COURSE", theCourseId };
}

export function AddCourse() {
  return { type: "ADD_NEW_COURSE" };
}

export function DeletePost() {
  return { type: "DELETE_POST" };
}

export function AddCourseToCart(courseItem) {
  return { type: "ADD_COURSE_TO_CART", courseItem };
}

export function FetchPostsAsync() {
  return { type: "FETCH_POSTS_REQUESTED" };
}

// Using Redux-thunk
// export function FetchPosts(posts) {
//   return { type: "FETCH_POSTS", posts };
// }

// export function FetchPostsAsync() {
//   return (dispatch) => {
//     axios
//       .get("https://jsonplaceholder.typicode.com/posts")
//       .then((response) => dispatch(FetchPosts(response.data))).catch(err=>);
//   };
// }

//axios.get("https://jsonplaceholder.typicode.com/posts").then((response) => {});
