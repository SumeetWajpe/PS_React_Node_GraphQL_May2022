export function courses(defStore = [], action) {
  let index;
  switch (action.type) {
    case "INCREMENT_LIKES":
      // console.log("Within courses reducer !", action);
      // console.log(action.theCourseId);
      index = defStore.findIndex((c) => c.id == action.theCourseId);
      // defStore[index].likes++; // new Store
      // return defStore; // immutable !

      return [
        ...defStore.slice(0, index),
        {
          ...defStore[index],
          likes: defStore[index].likes + 1,
        },
        ...defStore.slice(index + 1),
      ];

    case "DELETE_COURSE":
      index = defStore.findIndex((c) => c.id == action.theCourseId);
      return [...defStore.slice(0, index), ...defStore.slice(index + 1)]; // filter

    default:
      console.log("Within default case of Courses Reducer !!");
      return defStore;
  }
}
