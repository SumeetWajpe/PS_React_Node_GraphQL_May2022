const graphql = require("graphql");

const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLSchema,
  GraphQLID,
  GraphQLList,
  GraphQLInt,
} = graphql;

//dummy data
var booksList = [
  {
    id: "1",
    name: "Wings Of Fire",
    category: "Autobiography",
    authorId: "1",
  },
  {
    id: "2",
    name: "India 2020",
    category: "Inspirational",
    authorId: "1",
  },
  {
    id: "3",
    name: "Mrutyunjay",
    category: "Inspirational",
    authorId: "2",
  },
];

var authorsList = [
  { id: "1", name: "Dr. APJ Abdul Kalam", age: 70 },
  { id: "2", name: "Shivaji Sawant", age: 75 },
  { id: "3", name: "Ranjit Desai", age: 50 },
];

const BookType = new GraphQLObjectType({
  name: "Book",
  fields: () => ({
    id: { type: GraphQLID },
    name: { type: GraphQLString },
    category: { type: GraphQLString },
    author: {
      type: AuthorType,
      resolve(parent, args) {
        console.log(parent);
        return authorsList.find((a) => a.id == parent.authorId);
      },
    },
  }),
});

const AuthorType = new GraphQLObjectType({
  name: "Author",
  fields: () => ({
    id: { type: GraphQLID },
    name: { type: GraphQLString },
    age: { type: GraphQLInt },
    books: {
      type: new GraphQLList(BookType),
      resolve(parent, args) {
        return booksList.filter((book) => book.authorId === parent.id);
      },
    },
  }),
});

const RootQuery = new GraphQLObjectType({
  name: "RootQueryType",
  fields: {
    book: {
      type: BookType,
      args: { id: { type: GraphQLID } },
      resolve(parent, args) {
        // code to get data (from database)
        // console.log(typeof args.id);
        return booksList.find((b) => b.id == args.id);
      },
    },
    books: {
      type: new GraphQLList(BookType),
      resolve(parent, args) {
        return booksList;
      },
    },
    author: {
      type: AuthorType,
      args: { id: { type: GraphQLID } },
      resolve(parent, args) {
        // code to get data (from database)
        // console.log(typeof args.id);
        return authorsList.find((a) => a.id == args.id);
      },
    },

    authors: {
      type: new GraphQLList(AuthorType),
      resolve(parent, args) {
        return authorsList;
      },
    },
  },
});

const Mutation = new GraphQLObjectType({
  name: "Mutation",
  fields: {
    addAuthor: {
      type: AuthorType,
      args: {
        id: { type: GraphQLID },
        name: { type: GraphQLString },
        age: { type: GraphQLInt },
      },
      resolve(parent, args) {
        let newAuthor = {
          id: args.id,
          name: args.name,
          age: args.age,
        };
        authorsList.push(newAuthor);
        console.log(authorsList.length);
        return newAuthor;
      },
    },
    addBook: {
      type: BookType,
      args: {
        id: { type: GraphQLID },
        name: { type: GraphQLString },
        category: { type: GraphQLString },
        authorId: { type: GraphQLID },
      },
      resolve(parent, args) {
        let newBook = {
          id: args.id,
          name: args.name,
          category: args.category,
          authorId: args.authorId,
        };
        booksList.push(newBook);
        return newBook;
      },
    },
  },
});

module.exports = new GraphQLSchema({
  query: RootQuery,
  mutation: Mutation,
});

// graphql query

/*
-------------------------------------------- Book with id ------------
{
    book(id:"1"){
        name
    }
--------------------------------------------- Author with id (GraphQLID) -----------
    author(id:1){
        name
    }
-------------------------------------------- Collection ------------
    {
        books{
            name
        }
    }
---------------------------------------- Nesting -------------
   {
  book(id:1){
    name
    category
    author{
      name
    }
  }
}
-------------------------------- Find books written by an author -------
{
  author(id:1){
    name
    books{
      name
      category
    }
  }
}

---------------------------------------- Mutation (Add Author)-------------------------------
mutation{
  addAuthor(id:5,name:"Sudha Murty",age:60){
    name
    age
  }
}

------------------------------------  Mutation (Add Book) ---------------

mutation{
  addBook(id:4,name:"Three Thousand Stitches",category:"Inspirational",authorId:"5"){
    name
  }
}


*/
