const express = require("express");
const { ApolloServer, gql } = require("apollo-server");

var courseList = [
  {
    id: 1,
    title: "React",
    price: 5000,
    likes: 400,
    rating: 5,
    imageUrl:
      "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",
    trainerId: 1,
  },
  {
    id: 2,
    title: "Redux",
    price: 4000,
    likes: 600,
    rating: 5,
    imageUrl: "https://logicalidea.co/wp-content/uploads/2020/05/Redux.jpg",
    trainerId: 1,
  },
  {
    id: 3,
    title: "Node",
    price: 6000,
    likes: 900,
    rating: 4,
    imageUrl:
      "https://www.cloudsavvyit.com/p/uploads/2019/07/2350564e.png?width=1198&trim=1,1&bg-color=000&pad=1,1",
    trainerId: 2,
  },
  {
    id: 4,
    title: "Angular",
    price: 5000,
    likes: 200,
    rating: 3,
    imageUrl:
      "https://bs-uploads.toptal.io/blackfish-uploads/blog/post/seo/og_image_file/og_image/15991/top-18-most-common-angularjs-developer-mistakes-41f9ad303a51db70e4a5204e101e7414.png",
    trainerId: 3,
  },
  {
    id: 5,
    title: "Flutter",
    price: 7000,
    likes: 700,
    rating: 4,
    imageUrl: "https://miro.medium.com/max/2000/1*PCKC8Ufml-wvb9Vjj3aaWw.jpeg",
    trainerId: 1,
  },
];

var trainersList = [
  { id: 1, name: "Sumeet Wajpe", age: 38, isMCT: true },
  { id: 2, name: "Gulshan Sachdev", age: 45, isMCT: false },
  { id: 3, name: "Rachana Ranade", age: 32, isMCT: true },
];

const typeDefs = gql`
  #rootQuery
  type Query {
    hello: String
    courses: [Course]
  }

  type Course {
    id: ID!
    title: String
    price: Int
    likes: Int
    rating: Int
    imageUrl: String
  }

  type Mutation {
    addCourse(
      id: ID!
      title: String!
      price: Int!
      likes: Int
      imageUrl: String
      rating: Int
      trainerId: Int
    ): Course
  }
`;

const resolvers = {
  Query: {
    hello: () => "Hello Apollo Server !",
    courses: (parent, args) => courseList,
  },
  Mutation: {
    addCourse: (
      parent,
      { id, title, price, rating, likes, imageUrl, trainerId }
    ) => {
      const newCourse = {
        id,
        title,
        price,
        rating,
        likes,
        imageUrl,
        trainerId,
      };
      courseList.push(newCourse);
      return newCourse;
    },
  },
};

const server = new ApolloServer({
  typeDefs,
  resolvers,
});

// The `listen` method launches a web server.
server.listen().then(({ url }) => {
  console.log(`🚀  Server ready at ${url}`);
});

/*


query ExampleQuery {
  hello
  courses {
    id
    name
    price
    likes
    rating
    imageUrl
  }
}



mutation{
  addCourse(id:6 , title:"StencilJS",price:5000 ) {
   title 
  }
}

*/
