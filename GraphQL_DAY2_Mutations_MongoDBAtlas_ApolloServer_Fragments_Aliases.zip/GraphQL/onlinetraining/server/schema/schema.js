const graphql = require("graphql");

const Trainers = require("../models/trainers");
const Courses = require("../models/courses");

const {
  GraphQLObjectType,
  GraphQLString,
  GraphQLSchema,
  GraphQLID,
  GraphQLList,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLNonNull,
} = graphql;

const CourseType = new GraphQLObjectType({
  name: "Course",
  description: "Course Type having id,title,price,rating,likes,imageUrl",
  fields: () => ({
    id: { type: GraphQLID },
    title: { type: GraphQLString },
    price: { type: GraphQLInt },
    rating: { type: GraphQLInt },
    likes: { type: GraphQLInt },
    imageUrl: { type: GraphQLString },
    trainer: {
      type: TrainerType,
      resolve(parent, args) {
        //return trainersList.find((t) => t.id == parent.trainerId);
      },
    },
  }),
});

const TrainerType = new GraphQLObjectType({
  name: "Trainer",
  fields: () => ({
    id: { type: GraphQLID },
    name: { type: GraphQLString },
    age: { type: GraphQLInt },
    isMCT: { type: GraphQLBoolean },
    courses: {
      type: new GraphQLList(CourseType),
      resolve(parent, args) {
        //return courseList.filter((course) => course.trainerId === parent.id);
        return Courses.find({ trainerId: parent.id });
      },
    },
  }),
});

const RootQuery = new GraphQLObjectType({
  name: "RootQueryType",
  fields: {
    course: {
      type: CourseType,
      description: "return a single course",
      args: { id: { type: GraphQLID } },
      resolve(parent, args) {
        // code to get data (from database)
        //return courseList.find((c) => c.id == args.id);
        return Courses.findOne({ id: args.id });
      },
    },
    courses: {
      type: new GraphQLList(CourseType),
      description: "returns list of all courses",
      resolve(parent, args) {
        // return courseList;
        return Courses.find({});
      },
    },
    trainer: {
      type: TrainerType,
      args: { id: { type: GraphQLID } },
      resolve(parent, args) {
        // code to get data (from database)
        return Trainers.findOne({ id: args.id });
      },
    },
    trainers: {
      type: new GraphQLList(TrainerType),
      resolve(parent, args) {
        //return trainersList;
        return Trainers.find({});
      },
    },
  },
});

const Mutation = new GraphQLObjectType({
  name: "Mutation",
  fields: {
    addTrainer: {
      type: TrainerType,
      description: "add a new trainer to trainer list",
      args: {
        id: { type: new GraphQLNonNull(GraphQLID) },
        name: { type: new GraphQLNonNull(GraphQLString) },
        age: { type: GraphQLInt },
        isMCT: { type: GraphQLBoolean },
      },
      resolve(parent, args) {
        // create a new trainer
        let newTrainer = {
          id: args.id,
          name: args.name,
          age: args.age,
          isMCT: args.isMCT,
        };
        return Trainers.create(newTrainer);
      },
    },

    deleteTrainer: {
      type: TrainerType,
      description: "delete an existing trainer from the trainer list",
      args: {
        id: { type: GraphQLID },
      },
      resolve(parent, args) {
        return Trainers.deleteOne({ id: args.id });
      },
    },

    addCourse: {
      type: CourseType,
      description: "add a new course to course list",
      args: {
        id: { type: GraphQLID },
        title: { type: GraphQLString },
        price: { type: GraphQLInt },
        rating: { type: GraphQLInt },
        likes: { type: GraphQLInt },
        imageUrl: { type: GraphQLString },
        trainerId: { type: GraphQLID },
      },
      resolve(parent, args) {
        // create a new course
        let newCourse = {
          id: args.id,
          title: args.title,
          price: args.price,
          likes: args.likes,
          rating: args.rating,
          imageUrl: args.imageUrl,
          trainerId: args.trainerId,
        };

        return Courses.create(newCourse);
      },
    },

    deleteCourse: {
      type: CourseType,
      description: "delete an existing course from the course list",
      args: {
        id: { type: GraphQLID },
      },
      resolve(parent, args) {
        return Courses.deleteOne({ id: args.id });
      },
    },
  },
});

module.exports = new GraphQLSchema({
  query: RootQuery,
  mutation: Mutation,
});

// Mutations
// - add course
// - add trainer
// - delete course
// - delete trainer

// graphql query

/*
{
  trainer(id:1){
    name
    courses{
      id
      title
      likes
    }
  }
}

--------------------------------- Combine Query ---------------

{
  courses{
    title
    trainer{
      name
    }
  }
  
  trainer(id:1){
    name
  }
}

----------------------------------- aliases ------------------------------
{
  trainer1: trainer(id:1){
    name
  }
  
  trainer2: trainer(id:2){
    name
  }
}

-------------------- Fragements -------------------------
{
  trainer1: trainer(id:1){
    ...trainerDetails
  }
  
  trainer2: trainer(id:2){
     ...trainerDetails
  }
}

fragment trainerDetails on Trainer{
   id
    name
    age
    isMCT
}


---------------------------------- Mutation --------------------
mutation{
  addCourse(id:6,title:"StencilJS",price:4000,rating:5,likes:300,imageUrl:"xyz",trainerId:2){
    title
  }
}

---------------------------- Mutation with aliases ---------------------
mutation{
  first:addCourse(id:1,title:"React",price:5000,rating:5,likes:300,imageUrl:"https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",trainerId:1){
    title
  }
  second:addCourse(id:2,title:"Redux",price:4000,rating:4,likes:600,imageUrl:"https://logicalidea.co/wp-content/uploads/2020/05/Redux.jpg",trainerId:2){
    title
  }
   third:addCourse(id:3,title:"Node",price:5000,rating:5,likes:300,imageUrl:"https://www.cloudsavvyit.com/p/uploads/2019/07/2350564e.png?width=1198&trim=1,1&bg-color=000&pad=1,1",trainerId:2){
    title
  }
  fourth:addCourse(id:4,title:"Angular",price:5000,rating:5,likes:300,imageUrl:"https://bs-uploads.toptal.io/blackfish-uploads/blog/post/seo/og_image_file/og_image/15991/top-18-most-common-angularjs-developer-mistakes-41f9ad303a51db70e4a5204e101e7414.png",trainerId:2){
    title
  }
  fifth:addCourse(id:5,title:"Flutter",price:8000,rating:4,likes:900,imageUrl:"https://miro.medium.com/max/2000/1*PCKC8Ufml-wvb9Vjj3aaWw.jpeg",trainerId:2){
    title
  }
  
}
*/
