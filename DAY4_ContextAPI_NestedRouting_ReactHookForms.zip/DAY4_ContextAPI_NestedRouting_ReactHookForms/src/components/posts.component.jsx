import React, { Component } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

export class Posts extends Component {
  state = { allPosts: [] };
  componentDidMount() {
    axios
      .get("https://jsonplaceholder.typicode.com/posts")
      .then((response) => this.setState({ allPosts: response.data }));
  }

  render() {
    var postsToBeCreated = this.state.allPosts.map((post) => (
      <li className="list-group-item" key={post.id}>
        <Link to={`/postdetails/${post.id}`}> {post.title}</Link>
      </li>
    ));

    var content = null;

    return (
      <>
        <h2>All Posts</h2>
        {this.state.allPosts.length == 0 ? (
          <img
            src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif"
            alt="Loading.."
          />
        ) : (
          <ul className="list-group">{postsToBeCreated}</ul>
        )}
      </>
    );
  }
}

export default Posts;
