import React from "react";

/* 1. No render method 
    2. No State - this.state
    3. No Lifecycle Methods
*/

export function MessageAsFunctional(props) {
  return <h2>{props.msg}</h2>;
}
