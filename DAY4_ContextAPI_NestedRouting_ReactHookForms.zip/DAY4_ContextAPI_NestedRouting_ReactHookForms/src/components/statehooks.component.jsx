import React, { useState } from "react";

export function Counter() {
  let [count, setCount] = useState(200); // available in 16.8+
  let [age, setAge] = useState(18);

  return (
    <>
      <h3>Count : {count} </h3>
      <button onClick={() => setCount(count + 1)}>++</button>

      <hr />
      <h3>Age : {age} </h3>
      <button onClick={() => setAge(age + 1)}>++</button>
    </>
  );
}

// export function Counter() {
//     let [count, setCount] = useState({ currCount: 200, age: 18 });
//     return (
//       <>
//         <h3>Count : {count.currCount} </h3>
//         <h3>Age : {count.age} </h3>

//         <button
//           onClick={() => setCount({ ...count, currCount: count.currCount + 1 })}
//         >
//           ++
//         </button>
//       </>
//     );
//   }
