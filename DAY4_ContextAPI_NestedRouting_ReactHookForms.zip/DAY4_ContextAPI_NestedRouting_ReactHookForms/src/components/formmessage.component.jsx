import React, { Component } from "react";
import Message from "./themessage.component";

export default class FormMessage extends Component {
  state = { message: "" };
  HandleInput(event) {
    this.setState({ message: event.target.value });
  }
  render() {
    return (
      <form>
        <label htmlFor="txtMsg">Message : </label>{" "}
        <input type="text" id="txtMsg" onInput={(e) => this.HandleInput(e)} />
        <Message theMsg={this.state.message} />
      </form>
    );
  }
}
