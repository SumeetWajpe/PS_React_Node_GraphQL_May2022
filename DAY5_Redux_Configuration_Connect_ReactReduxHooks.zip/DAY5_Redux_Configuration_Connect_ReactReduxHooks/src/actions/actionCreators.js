const INCREMENT_LIKES = "INCREMENT_LIKES"; // best practice !

export function IncrementLikes(theCourseId) {
  return { type: INCREMENT_LIKES, theCourseId };
}

export function DeleteCourse() {
  return { type: "DELETE_COURSE" };
}

export function AddCourse() {
  return { type: "ADD_NEW_COURSE" };
}

export function DeletePost() {
  return { type: "DELETE_POST" };
}
