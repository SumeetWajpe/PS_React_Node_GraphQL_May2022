import React from "react";
import FormMessage from "./components/formmessage.component";
import ListOfCourses from "./components/listofcourses.component";

class App extends React.Component {
  render() {
    return (
      <>
        <ListOfCourses />
        {/* <FormMessage /> */}
      </>
    );
  }
}

export default App;
