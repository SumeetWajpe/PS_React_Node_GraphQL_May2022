function fetchCourses() {
  fetch("http://localhost:3000/courses")
    .then((res) => res.json())
    .then((courses) => console.log(courses));
}

window.addEventListener("DOMContentLoaded", () => fetchCourses());
