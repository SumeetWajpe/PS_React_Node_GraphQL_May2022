const http = require("http");
var fs = require("fs");
const hostname = "127.0.0.1";
const port = 3000;

const server = http.createServer((req, res) => {
  if (req.url == "/products" && req.method == "GET") {
    // would come from db !
    var products = [
      { id: 1, title: "LED TV", price: 50000 },
      { id: 2, title: "OLED TV", price: 100000 },
    ];
    // send JSON
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(products));
  }
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
