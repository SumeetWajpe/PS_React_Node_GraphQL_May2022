const express = require("express");
var courses = require("../model/course.model");
var path = require("path");
var fs = require("fs");

let router = express.Router();

router.route("/").get((req, res) => {
  res.render("courses", { listofcourses: courses, title: "List Of Courses" });
});

router.route("/coursedetails/:cid").get((req, res) => {
  let courseId = +req.params.cid;
  let course = courses.find((c) => c.id === courseId);
  res.render("coursedetails", { course });
});

router.get("/video/:cid", (req, res) => {
  let theCourseId = +req.params.cid;
  let theCourse = courses.find((c) => c.id === theCourseId);

  const range = req.headers.range;

  // get video stats
  const videopath = theCourse.introVideo;
  const videoSize = fs.statSync(videopath).size;
  console.log(videoSize);

  // range
  const CHUNK_SIZE = 10 ** 6; // 1 MB
  const start = Number(range.replace(/\D/g, ""));
  const end = Math.min(start + CHUNK_SIZE, videoSize - 1);

  // headers
  const contentLength = end - start + 1;
  const headers = {
    "Content-Range": `bytes ${start}-${end}/${videoSize}`,
    "Accept-Ranges": "bytes",
    "Content-Length": contentLength,
    "Content-Type": "video/mp4",
  };

  res.writeHead(206, headers);
  // read the video as a readableStream
  const videoStream = fs.createReadStream(videopath, { start, end });

  // stream the video as response to the client !
  videoStream.pipe(res);
});

module.exports = router;
