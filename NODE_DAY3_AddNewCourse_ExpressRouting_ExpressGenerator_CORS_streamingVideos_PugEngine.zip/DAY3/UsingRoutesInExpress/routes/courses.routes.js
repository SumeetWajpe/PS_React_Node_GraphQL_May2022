const express = require("express");
var courses = require("../model/course.model");

let router = express.Router();

router.route("/courses").get((req, res) => {
  res.json(courses);
});

router.route("/course/:id").delete((req, res) => {
  let theCourseId = +req.params.id; // converts to number
  courses = courses.filter((course) => course.id !== theCourseId);
  res.json({ msg: "success" });
  //logic for delete - db
});

router.route("/newcourse").post((req, res) => {
  // logic to add new course !
  // console.log(req.body);
  var newCourse = req.body;
  courses.push(newCourse); // save it to db !
  res.json({ msg: "success" });
});

module.exports = router;
